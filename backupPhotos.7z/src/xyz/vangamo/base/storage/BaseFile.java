package xyz.vangamo.base.storage;

public class BaseFile extends File {
    //  Hand class to avoid File from nio.

	protected BaseFile(String[] fields) {
		super(fields);
		// TODO Auto-generated constructor stub
	}

	private static final long serialVersionUID = 3669201130813297593L;
    }